import { Directive } from '@angular/core';

@Directive({
  selector: '[appTesting]'
})
export class TestingDirective {

  constructor() { }

}
