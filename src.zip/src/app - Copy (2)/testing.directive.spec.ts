import { TestingDirective } from './testing.directive';

describe('TestingDirective', () => {
  it('should create an instance', () => {
    const directive = new TestingDirective();
    expect(directive).toBeTruthy();
  });
});
