import { Component } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
})
export class AppComponent { 

  posts : any[];
  private url = "https://jsonplaceholder.typicode.com/posts";
   constructor(private http: Http) { }
   httpdata;
   ngOnInit() {
    this.http.get(this.url)
      .subscribe( response =>{
        this.posts = response.json();
      });
   }
   createPost(input:HTMLInputElement){
     let post = { title:input.value };
     input.value =''; 
      this.http.post(this.url,JSON.stringify(post))
      .subscribe(response=>{
        post['id'] = response.json().id;
        this.posts.splice(0, 0, post);
        console.log(response.json());
      });
   }
}