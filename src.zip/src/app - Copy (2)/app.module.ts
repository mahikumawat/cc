import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule , Routes } from '@angular/Router';
import { AppComponent } from './app.component';
import { HeroesComponent } from './heroes/heroes.component';
import { HeroDetailComponent } from './hero-detail/hero-detail.component';
import { MyserviceService } from './myservice.service';
import { TestingDirective } from './testing.directive';
import { FeaturesComponent } from './features/features.component';
import { PricingComponent } from './pricing/pricing.component';
import { componentFactoryName } from '@angular/compiler';
import { SidebarComponent } from './sidebar/sidebar.component';
import { PostsComponent } from './posts/posts.component';

let routes: Routes =[
  {
    path: "features",
    component : FeaturesComponent
  },
  {
    path: "post",
    component : PostsComponent
  },
  {
  path: "pricing",
  component : PricingComponent
}
]

@NgModule({
  declarations: [
    AppComponent,
    HeroesComponent,
    HeroDetailComponent,
    TestingDirective,
    FeaturesComponent,
    PricingComponent,
    SidebarComponent,
    PostsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes, {useHash:true}),
  ],
  providers: [
    MyserviceService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule {



 }
