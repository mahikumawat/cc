import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
 
})
export class HomeComponent implements OnInit {
  private apiUrl = 'http://localhost/wordpress/api/services_api.php';
  private apiUrl2  = "http://localhost/wordpress/api/portfolio.php";
  private sliderUr = "http://localhost/wordpress/api/slider.php" ;
  private whatwedo ="http://localhost/wordpress/api/what_we_do.php";
  private aboutdata ="http://localhost/wordpress/api/abouthome.php";

  httpdata;
  articles;
  testttt;
  whatwedoData;
  getabutData;
  


  constructor(private http: Http) {
    
    
    this.http.get(this.apiUrl)
    .map((response) => response.json())
    .subscribe((data) => {this.displaydata(data);
   })
     this.http.get(this.apiUrl2)
     .map((res) => res.json())
     .subscribe((data) => {this.showdata(data);
   })
     this.http.get(this.sliderUr)
     .map((res) => res.json())
     .subscribe((data) => {this.showslider(data);
   })
   this.http.get(this.whatwedo)
   .map((res) => res.json())
   .subscribe((data) => {this.whatdoData(data);
 })
   this.http.get(this.aboutdata)
   .map((response) => response.json())
   .subscribe((data) => {this.aboutContent(data);
   })
  }

  ngOnInit() {
 
  }
  displaydata(data) {this.httpdata = data;
  // console.log(data);
  }
  showslider(data) {this.testttt = data;
    //console.log(data);
   }
  showdata(data) {this.articles = data;
    //console.log(data);
  }
  whatdoData(data) {this.whatwedoData = data;
    //console.log(data);
  }
  aboutContent(data) {this.getabutData = data;
    //console.log(data);
  }
}
