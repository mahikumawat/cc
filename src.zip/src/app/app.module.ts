import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule , Routes } from '@angular/Router';
import { AppComponent } from './app.component';
import { HeroesComponent } from './heroes/heroes.component';
import { HeroDetailComponent } from './hero-detail/hero-detail.component';
import { MyserviceService } from './myservice.service';
import { TestingDirective } from './testing.directive';
import { FeaturesComponent } from './features/features.component';
import { PricingComponent } from './pricing/pricing.component';
import { componentFactoryName } from '@angular/compiler';
import { SidebarComponent } from './sidebar/sidebar.component';
import { PostsComponent } from './posts/posts.component';
import { HeaderComponent }  from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AboutComponent } from './about/about.component';
import { ServicesComponent } from './services/services.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { environment } from '../environments/environment';


let routes: Routes =[
  {
    path: "about",
    component : AboutComponent
  },
  {
    path: "services",
    component : ServicesComponent
  },
  {
  path: "portfolio",
  component : PortfolioComponent
},
{
  path: "testimonials",
  component : TestimonialsComponent
},
{
  path: "contact",
  component : ContactComponent
}
, {
  path: '**',
  component:HomeComponent
}
]

@NgModule({
  declarations: [
    AppComponent,
    HeroesComponent,
    HeroDetailComponent,
    TestingDirective,
    FeaturesComponent,
    PricingComponent,
    SidebarComponent,
    PostsComponent,
    HeaderComponent,
    FooterComponent,
    AboutComponent,
    ServicesComponent,
    PortfolioComponent,
    TestimonialsComponent,
    ContactComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    
    RouterModule.forRoot(routes, {useHash:true}),
  ],
  providers: [
    MyserviceService,
  ],

  bootstrap: [AppComponent]
})
export class AppModule {



 }
