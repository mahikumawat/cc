import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import { Http } from '@angular/http';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  private aboutdata ="http://localhost/wordpress/api/abouthome.php";
  private getdata ="http://localhost/wordpress/api/aboutpost.php";
  getabutData;
  aboutData;
  
  constructor(private http: Http) {
    this.http.get(this.aboutdata)
    .map((response) => response.json())
    .subscribe((data) => {this.aboutContent(data);
    })

    this.http.get(this.getdata)
    .map((response) => response.json())
    .subscribe((data) => {this.fetchdata(data);
    })
   }
   aboutContent(data) {
     this.getabutData = data;
     console.log(data);
    
  }
  fetchdata(data) {
    this.aboutData = data;
   //console.log(data);
 }
  ngOnInit() {
   
  }

}
