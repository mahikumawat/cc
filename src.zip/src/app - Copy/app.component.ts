import { Component } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
})
export class AppComponent {

title = 'To Do List';  
TaskList =[];
task = '';
show:boolean = false;
fcolor ="";
countTask = 0;
size:number = 20;
private apiUrl = 'http://localhost/bharossa/bharosaadmin/api/view_new_user_product.php';
// private apiUrls = 'http://jsonplaceholder.typicode.com/users';
  // this.http.get("http://jsonplaceholder.typicode.com/users").

addTask(){
  if(this.task !=""){
    this.TaskList.push(this.task);
    this.countTask=this.TaskList.length;
    this.task='';
  }
}
removeTask(index){
  this.TaskList.splice(index,1);
  this.countTask=this.TaskList.length;

}
   constructor(private http: Http) { }
   httpdata;
   ngOnInit() {
    this.http.get(this.apiUrl).
      map(
         (response) => response.json()
      ).
      subscribe(
         (data) => {this.displaydata(data);}
      )
   }
   changeBlock(){
     this.show = !this.show;
   }
   displaydata(data) {this.httpdata = data;
    // console.log(data);
  }
  changeColor(val){
    this.fcolor = val;
  }
  createPost(input: HTMLInputElement){
    let post= {title: input.value};
    this.http.post(this.apiUrl, JSON.stringify(post))
    .subscribe(response=>{
      console.log(response.json());
    });
  }
}