export const environment = {
  production: true,
  baseUrl: 'https://jsonplaceholder.typicode.com'
  
};
